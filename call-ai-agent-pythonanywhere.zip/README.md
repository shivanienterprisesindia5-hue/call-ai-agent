# 🤖 Call AI Agent - PythonAnywhere Deployment

## 🚀 Deploy in 5 Minutes (No GitHub Needed!)

### Step 1: Sign Up on PythonAnywhere
1. Go to [pythonanywhere.com](https://www.pythonanywhere.com)
2. Click "Start running Python online in less than a minute"
3. Create FREE account

### Step 2: Upload Files
1. Go to "Files" tab
2. Create folder: `call-ai-agent`
3. Upload ALL files from this ZIP:
   - `app.py`
   - `requirements.txt`
   - `wsgi.py`
   - `templates/dashboard.html`
4. Create folder: `logs/conversations`

### Step 3: Install Dependencies
1. Go to "Consoles" tab
2. Click "Bash"
3. Run:
```bash
pip install --user -r /home/aapkausername/call-ai-agent/requirements.txt
```

### Step 4: Create Web App
1. Go to "Web" tab
2. Click "Add a new web app"
3. Select "Flask"
4. Select Python 3.11
5. Set path: `/home/aapkausername/call-ai-agent/app.py`

### Step 5: Configure WSGI
1. In Web tab, click WSGI file link
2. Replace content with:
```python
import sys
path = '/home/aapkausername/call-ai-agent'
if path not in sys.path:
    sys.path.append(path)

from app import app as application
```
3. Save

### Step 6: Add Environment Variables
1. In Web tab, scroll to "Environment variables"
2. Add:
```
OPENAI_API_KEY=sk-your-key
TWILIO_ACCOUNT_SID=ACxxxxxxxx
TWILIO_AUTH_TOKEN=your-token
TWILIO_PHONE_NUMBER=+91XXXXXXXXXX
PYTHONANYWHERE_URL=https://aapkausername.pythonanywhere.com
```

### Step 7: Reload
Click **"Reload"** button!

### Step 8: Configure Twilio
1. Go to [Twilio Console](https://console.twilio.com)
2. Set webhooks:
   - A call comes in: `https://aapkausername.pythonanywhere.com/answer` (POST)
   - Call Status Changes: `https://aapkausername.pythonanywhere.com/call-ended` (POST)

### Step 9: Test! 🎉
- Dashboard: `https://aapkausername.pythonanywhere.com`
- Call your Twilio number!

## ✨ Features
- 📞 Answer phone calls 24/7
- 🎤 Hindi/English/Hinglish support
- 🤖 AI-powered responses
- 📊 Live dashboard
- 📝 Call logs

## 📝 Customize
Edit `SYSTEM_PROMPT` in `app.py` to change AI personality and business info.
