#!/usr/bin/env python3
"""
🤖 Call AI Agent - PythonAnywhere Version
Easiest deployment - no GitHub needed!
"""

import os
import json
from datetime import datetime
from pathlib import Path

from flask import Flask, request, render_template, jsonify, Response
from flask_cors import CORS
from twilio.twiml.voice_response import VoiceResponse, Gather
from twilio.rest import Client as TwilioClient
import openai

app = Flask(__name__)
CORS(app)

# API Keys from environment variables
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
TWILIO_ACCOUNT_SID = os.getenv("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN = os.getenv("TWILIO_AUTH_TOKEN", "")
TWILIO_PHONE_NUMBER = os.getenv("TWILIO_PHONE_NUMBER", "")

# Base URL (PythonAnywhere provides this)
BASE_URL = os.getenv("PYTHONANYWHERE_URL", "")
if not BASE_URL:
    # For local testing
    BASE_URL = "http://localhost:5000"

# Initialize clients
openai.api_key = OPENAI_API_KEY
twilio_client = TwilioClient(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN) if TWILIO_ACCOUNT_SID else None

# Data storage
CONVERSATIONS_DIR = Path("logs/conversations")
CONVERSATIONS_DIR.mkdir(parents=True, exist_ok=True)

# Active calls tracking
active_calls = {}

# AI Personality - CUSTOMIZE THIS!
SYSTEM_PROMPT = """You are "Riya", a friendly and professional AI call assistant for an Indian business.

Your capabilities:
- Greet callers warmly in Hindi, English, or Hinglish
- Answer questions about business hours, services, pricing
- Take messages and note down important details
- Schedule appointments (collect name, date, time, purpose)
- Handle basic complaints professionally
- Transfer to human if needed
- Always be polite, patient, and helpful

Rules:
- Keep responses concise (2-3 sentences max for voice)
- Speak naturally, like a real person
- If you don't know something, say you'll pass the message
- Always confirm important details back to the caller
- Use simple Hindi/English mix if caller uses Hinglish
- Never make up facts about the business

Current business info:
- Business Name: [AAPKA_BUSINESS_NAME]
- Hours: 9 AM - 6 PM, Monday to Saturday
- Services: [AAPKI_SERVICES]
- Contact: [AAPKA_EMAIL]"""

# Helper Functions
def log_call(call_sid, event_type, data):
    timestamp = datetime.now().isoformat()
    log_entry = {"timestamp": timestamp, "call_sid": call_sid, "event": event_type, "data": data}

    conv_file = CONVERSATIONS_DIR / f"{call_sid}.json"
    conversations = []
    if conv_file.exists():
        with open(conv_file, "r", encoding="utf-8") as f:
            conversations = json.load(f)

    conversations.append(log_entry)

    with open(conv_file, "w", encoding="utf-8") as f:
        json.dump(conversations, f, ensure_ascii=False, indent=2)

    if call_sid not in active_calls:
        active_calls[call_sid] = {"started": timestamp, "from": data.get("from", "unknown"), "status": "active", "messages": []}

    if event_type == "user_message":
        active_calls[call_sid]["messages"].append({"role": "user", "content": data.get("text", ""), "timestamp": timestamp})
    elif event_type == "ai_response":
        active_calls[call_sid]["messages"].append({"role": "assistant", "content": data.get("text", ""), "timestamp": timestamp})

def get_conversation_history(call_sid):
    conv_file = CONVERSATIONS_DIR / f"{call_sid}.json"
    if not conv_file.exists():
        return []

    with open(conv_file, "r", encoding="utf-8") as f:
        conversations = json.load(f)

    messages = []
    for entry in conversations:
        if entry["event"] == "user_message":
            messages.append({"role": "user", "content": entry["data"].get("text", "")})
        elif entry["event"] == "ai_response":
            messages.append({"role": "assistant", "content": entry["data"].get("text", "")})

    return messages

def generate_ai_response(call_sid, user_text):
    try:
        history = get_conversation_history(call_sid)
        messages = [{"role": "system", "content": SYSTEM_PROMPT}]
        messages.extend(history[-5:])
        messages.append({"role": "user", "content": user_text})

        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=messages,
            max_tokens=150,
            temperature=0.7
        )

        return response.choices[0].message.content.strip()

    except Exception as e:
        print(f"AI Error: {e}")
        return "Maaf kijiye, technical issue aa raha hai. Kripya thodi der baad call karein."

def create_twiml_response(text, gather=True, language="hi-IN"):
    response = VoiceResponse()
    response.say(text, voice="Polly.Aditi", language=language)

    if gather:
        gather_obj = Gather(
            input="speech",
            timeout=5,
            speech_timeout="auto",
            language=language,
            action="/process-speech",
            method="POST"
        )
        response.append(gather_obj)
        response.redirect("/no-speech")

    return str(response)

# Twilio Webhook Endpoints
@app.route("/answer", methods=['POST'])
def answer_call():
    call_sid = request.form.get('CallSid', 'unknown')
    caller = request.form.get('From', 'unknown')

    print(f"Incoming call from {caller} (SID: {call_sid})")

    log_call(call_sid, "call_started", {
        "from": caller,
        "to": request.form.get('To', ''),
        "direction": request.form.get('Direction', 'inbound')
    })

    welcome_text = "Namaste! Main Riya hoon, aapki virtual assistant. Aapki kaise madad kar sakti hoon?"

    return Response(create_twiml_response(welcome_text, gather=True), mimetype='application/xml')

@app.route("/process-speech", methods=['POST'])
def process_speech():
    call_sid = request.form.get('CallSid', 'unknown')
    user_speech = request.form.get('SpeechResult', '')
    confidence = request.form.get('Confidence', '0')

    print(f"User said: '{user_speech}'")

    if not user_speech:
        return Response(create_twiml_response(
            "Maine suna nahi. Kripya dobara bolein.", 
            gather=True
        ), mimetype='application/xml')

    log_call(call_sid, "user_message", {"text": user_speech, "confidence": confidence})

    ai_response = generate_ai_response(call_sid, user_speech)
    print(f"AI Response: '{ai_response}'")

    log_call(call_sid, "ai_response", {"text": ai_response})

    return Response(create_twiml_response(ai_response, gather=True), mimetype='application/xml')

@app.route("/no-speech", methods=['POST'])
def no_speech():
    call_sid = request.form.get('CallSid', 'unknown')
    log_call(call_sid, "no_speech", {})

    return Response(create_twiml_response(
        "Kya aap wahan hain? Main aapki madad karna chahti hoon.",
        gather=True
    ), mimetype='application/xml')

@app.route("/call-ended", methods=['POST'])
def call_ended():
    call_sid = request.form.get('CallSid', 'unknown')
    call_status = request.form.get('CallStatus', 'completed')

    print(f"Call ended: {call_sid} (Status: {call_status})")

    log_call(call_sid, "call_ended", {
        "status": call_status,
        "duration": request.form.get('CallDuration', '0')
    })

    if call_sid in active_calls:
        active_calls[call_sid]["status"] = "ended"
        active_calls[call_sid]["ended_at"] = datetime.now().isoformat()

    return Response("", mimetype='application/xml')

# Web Dashboard
@app.route("/")
def dashboard():
    return render_template("dashboard.html")

@app.route("/api/calls")
def get_calls():
    calls = []

    for conv_file in CONVERSATIONS_DIR.glob("*.json"):
        call_sid = conv_file.stem

        with open(conv_file, "r", encoding="utf-8") as f:
            conversations = json.load(f)

        call_info = {
            "call_sid": call_sid,
            "started": None,
            "ended": None,
            "duration": 0,
            "from": "unknown",
            "status": "unknown",
            "message_count": 0,
            "transcript": []
        }

        for entry in conversations:
            if entry["event"] == "call_started":
                call_info["started"] = entry["timestamp"]
                call_info["from"] = entry["data"].get("from", "unknown")
            elif entry["event"] == "call_ended":
                call_info["ended"] = entry["timestamp"]
                call_info["status"] = entry["data"].get("status", "completed")
                call_info["duration"] = entry["data"].get("duration", 0)
            elif entry["event"] in ["user_message", "ai_response"]:
                call_info["message_count"] += 1
                call_info["transcript"].append({
                    "role": "user" if entry["event"] == "user_message" else "assistant",
                    "text": entry["data"].get("text", ""),
                    "time": entry["timestamp"]
                })

        calls.append(call_info)

    calls.sort(key=lambda x: x["started"] or "", reverse=True)
    return jsonify(calls)

@app.route("/api/stats")
def get_stats():
    total_calls = len(list(CONVERSATIONS_DIR.glob("*.json")))
    active_count = sum(1 for info in active_calls.values() if info["status"] == "active")

    total_duration = 0
    for conv_file in CONVERSATIONS_DIR.glob("*.json"):
        with open(conv_file, "r", encoding="utf-8") as f:
            conversations = json.load(f)
        for entry in conversations:
            if entry["event"] == "call_ended":
                total_duration += int(entry["data"].get("duration", 0))

    return jsonify({
        "total_calls": total_calls,
        "active_calls": active_count,
        "total_duration_minutes": round(total_duration / 60, 2),
        "avg_duration_minutes": round(total_duration / 60 / max(total_calls, 1), 2)
    })

@app.route("/api/call/<call_sid>")
def get_call_detail(call_sid):
    conv_file = CONVERSATIONS_DIR / f"{call_sid}.json"

    if not conv_file.exists():
        return jsonify({"error": "Call not found"}), 404

    with open(conv_file, "r", encoding="utf-8") as f:
        conversations = json.load(f)

    return jsonify(conversations)

@app.route("/health")
def health():
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "twilio_configured": bool(twilio_client),
        "openai_configured": bool(OPENAI_API_KEY),
        "base_url": BASE_URL
    })

# PythonAnywhere WSGI entry point
application = app
