import sys
path = '/home/aapkausername/call-ai-agent'
if path not in sys.path:
    sys.path.append(path)

from app import app as application
