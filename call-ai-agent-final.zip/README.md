# Call AI Agent

AI-powered phone call assistant.

## Deploy on Render

1. Connect GitHub repo
2. Add environment variables
3. Deploy!
