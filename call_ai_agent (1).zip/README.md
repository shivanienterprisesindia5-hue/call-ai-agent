# 🤖 Call AI Agent - Cloud Ready

A complete AI-powered phone call assistant deployed on Render.com (FREE!)

## ✨ Features

- 📞 **Answer Phone Calls** - Automatically attends incoming calls via Twilio
- 🎤 **Speech Recognition** - Understands Hindi, English, and Hinglish
- 🤖 **AI-Powered Responses** - Uses OpenAI GPT for intelligent conversations
- 🔊 **Natural Voice** - High-quality text-to-speech
- 📊 **Web Dashboard** - Real-time call monitoring and transcripts
- 📤 **Outbound Calls** - Make calls directly from dashboard
- 📝 **Call Logging** - Complete conversation history
- 🌐 **Cloud Deployed** - Runs 24/7 on Render.com (free tier)

## 🚀 Deploy on Render.com (5 Minutes!)

### Step 1: Fork/Upload to GitHub

1. Create a new GitHub repository
2. Upload all these files to the repository
3. Make sure `render.yaml` is in the root

### Step 2: Deploy on Render

1. Go to [render.com](https://render.com) and sign up (free)
2. Click **"New +"** → **"Web Service"**
3. Connect your GitHub repository
4. Render will auto-detect `render.yaml` and configure everything
5. Click **"Create Web Service"**
6. Wait for deployment (2-3 minutes)

### Step 3: Add Environment Variables

In Render Dashboard → Your Service → Environment:

```
OPENAI_API_KEY=sk-your-openai-key
TWILIO_ACCOUNT_SID=ACxxxxxxxxxx
TWILIO_AUTH_TOKEN=your-auth-token
TWILIO_PHONE_NUMBER=+91XXXXXXXXXX
```

Click **Save Changes** - Render will auto-redeploy!

### Step 4: Get Your URL

After deployment, you'll get a URL like:
`https://call-ai-agent.onrender.com`

### Step 5: Configure Twilio

1. Go to [Twilio Console](https://console.twilio.com)
2. Phone Numbers → Manage → Active Numbers
3. Click your number
4. **A call comes in** → Webhook → POST
   - URL: `https://your-render-url.onrender.com/answer`
5. **Call Status Changes** → Webhook → POST
   - URL: `https://your-render-url.onrender.com/call-ended`
6. Save!

### Step 6: Test! 🎉

1. Open your Render URL in browser (Dashboard)
2. Call your Twilio number from your phone
3. Talk to the AI!

## 📁 Files

```
call_ai_agent/
├── app.py              # Main Flask application
├── requirements.txt    # Python dependencies
├── render.yaml         # Render.com configuration
├── .env.example        # Environment variables template
├── .gitignore         # Git ignore file
├── templates/
│   └── dashboard.html  # Web dashboard
└── logs/
    └── conversations/  # Call logs (auto-created)
```

## 🔧 Customization

### Change AI Name & Business Info
Edit `SYSTEM_PROMPT` in `app.py`:
```python
SYSTEM_PROMPT = """You are "AapkaNaam"...
Business Name: Aapka Business
Hours: 9 AM - 6 PM
Services: Jo bhi services hain
"""
```

### Change Language
In `app.py`, modify language parameter:
- Hindi: `hi-IN`
- English: `en-US`
- Tamil: `ta-IN`

## 💰 Costs

| Service | Free Tier | Paid |
|---------|-----------|------|
| **Render** | 750 hours/month | $7/month |
| **Twilio** | $15.50 trial | ~$1/month + per-minute |
| **OpenAI** | $5 trial | ~$0.002/1K tokens |

## 🆘 Troubleshooting

**App not starting?**
- Check Render logs for errors
- Verify all environment variables are set

**Calls not coming through?**
- Verify Twilio webhook URL is correct
- Make sure it starts with `https://`

**AI not responding?**
- Check OpenAI API key is valid
- Verify API key has available credits

## 📞 What Can It Do?

✅ Answer phone calls 24/7
✅ Understand Hindi/English/Hinglish
✅ Give smart responses
✅ Take messages
✅ Book appointments
✅ Handle complaints
✅ Live dashboard monitoring
✅ Make outbound calls

---

**Made with ❤️ for Indian Businesses**

Bolo, kaam karega! 🚀
